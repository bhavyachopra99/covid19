import 'package:http/http.dart' as http;
import 'datafinder.dart';

// ignore: camel_case_types
class cases {
  //
  static const String url = 'https://api.rootnet.in/covid19-in/stats/latest';

  static Future<List<Regional>> getregions() async {
    try {
      final response = await http.get(url);
      if (200 == response.statusCode) {
        final List<Regional> regional = datafinderFromJson(response.body);
        return regional;
      } else {
        return List<Regional>();
      }
    } catch (e) {
      return List<Regional>();
    }
  }
}